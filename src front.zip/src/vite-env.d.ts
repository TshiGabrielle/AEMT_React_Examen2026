/// <reference types="vite/client" />

declare module '*.css';
declare module '*.svg';