import { NotesLayout } from './features/notes/layouts/NotesLayout.js';
import './App.css';

function App() {
  return <NotesLayout />;
}

export default App;